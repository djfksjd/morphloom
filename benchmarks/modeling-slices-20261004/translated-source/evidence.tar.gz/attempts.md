# Attempts

1. Hypothesis: synthetic fixture adds matrix to an originally TRS/identity target, outside unchanged binding JSON contract. Restore quarantined files unchanged and reproduce before modifying fixture.

1 result: unchanged archived tests reproduced3FAIL, all at binding JSON comparison. Adapter preserves TRS vs matrix; fixture injected a matrix onto a target with no original matrix. Change fixture only to original-compatible translation. Add negative matrix/SHA/declaration cases; product binding unchanged.

2. Fixture follow-up: correct translation reaches existing legacy gear0.3 UV failure. Success fixture must use already supported0.4 UV scale100, matching actual native gear; do not disable legacy failure. No product threshold or binding changes.

3. Actual byte boundary evidence: raw position/normal/UV exact; Math.atan2 Float64 corner weights4675values differ (max2.22e-16); resulting Float32 normals12values differ(max1.10e-18), accessor layout exact. Initial decimal diagnostic was affected by CLI number serialization; byte-base64 diagnostic supersedes it. Implement explicit IEEE reduced atan series, no value rounding/tolerance pass, bump renderer0.12. Uniform path unchanged. Older weighted0.11 artifact still requires exact regeneration and cannot be promoted if bytes differ.

- Current four native browser exports/actual Blender declared translations: strict reconstruction PASS. Browser save → fresh reload → repeat GLB exact → additional edit/Undo/Redo PASS4. Sequential second delta and no-op preserve source exactly PASS4. Async reconstruction replacement/current failure/child unmount PASS6; prior inspection async PASS3 and tooth damage UI PASS8. Source/current/regenerated GLB strict PASS12; independent first-import correspondence PASS4. Raw Blender sphere normal fidelity remains FAIL separately (first import and reexport measured, threshold unchanged). Full test initial777/check/benchmark/build PASS; final unsupported test additions being verified. quality:gate/production exit1 at unchanged cross-domain receipt acceptance, not the new native path; current reports preserved separately, original tracked receipts restored.
