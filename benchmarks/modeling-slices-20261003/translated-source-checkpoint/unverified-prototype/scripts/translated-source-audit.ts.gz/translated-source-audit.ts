import fs from 'node:fs';
import assert from 'node:assert/strict';
import {reconstructTranslatedSource} from '../src/engine/translated-source';
const [original,current,output,receipt]=process.argv.slice(2);assert(original&&current&&output&&receipt&&!fs.existsSync(output)&&!fs.existsSync(receipt));
class Reader {result:ArrayBuffer|null=null;onloadend:(()=>void)|null=null;readAsArrayBuffer(blob:Blob){void blob.arrayBuffer().then(v=>{this.result=v;this.onloadend?.();});}}
Object.assign(globalThis,{FileReader:Reader});
const read=(file:string)=>new Uint8Array(fs.readFileSync(file)).buffer;
const result=await reconstructTranslatedSource(read(original),read(current));
fs.writeFileSync(output,result.sourceJson,{flag:'wx'});fs.writeFileSync(receipt,JSON.stringify(result.receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result.receipt));
