import {expect,it,vi} from 'vitest';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {generateSpurGearProject} from '../src/engine/gear-pack';
import {exportSelectedScene} from '../src/engine/element-renderer';
import {sha256} from '../src/engine/uv-quality';
import {reconstructTranslatedSource} from '../src/engine/translated-source';
function unpack(b:ArrayBuffer){const n=new DataView(b).getUint32(12,true);return {d:JSON.parse(new TextDecoder().decode(new Uint8Array(b,20,n))),bin:new Uint8Array(b,20+n).slice()};}
function pack(d:any,bin:Uint8Array){const text=new TextEncoder().encode(JSON.stringify(d)),n=Math.ceil(text.length/4)*4,b=new ArrayBuffer(20+n+bin.length),v=new DataView(b);v.setUint32(0,0x46546c67,true);v.setUint32(4,2,true);v.setUint32(8,b.byteLength,true);v.setUint32(12,n,true);v.setUint32(16,0x4e4f534a,true);new Uint8Array(b,20,n).fill(32);new Uint8Array(b,20,text.length).set(text);new Uint8Array(b,20+n).set(bin);return b;}
async function fixture(locked=false,alterNormals=false){
 class Reader{result:ArrayBuffer|null=null;onloadend:(()=>void)|null=null;readAsArrayBuffer(blob:Blob){void blob.arrayBuffer().then(v=>{this.result=v;this.onloadend?.();});}}
 vi.stubGlobal('FileReader',Reader);
 const project=generateSpurGearProject({});project.parts[0].locked=locked;
 const built=exportSelectedScene(project,['spur_gear']);
 try{
  let original=await new GLTFExporter().parseAsync(built.root,{binary:true}) as ArrayBuffer;
  if(alterNormals){const {d,bin}=unpack(original),a=d.accessors[d.meshes[0].primitives[0].attributes.NORMAL],offset=8+(d.bufferViews[a.bufferView].byteOffset??0)+(a.byteOffset??0);new DataView(bin.buffer,bin.byteOffset).setFloat32(offset,.25,true);original=pack(d,bin);}
  const {d,bin}=unpack(original),sourceFingerprint=await sha256(new Uint8Array(original));
  const owner=d.nodes.find((n:any)=>n.extras?.sourceSpec),ownerIndex=d.nodes.indexOf(owner),target=d.nodes.find((n:any)=>n.name==='spur_gear');
  target.matrix=[1,0,0,0,0,1,0,0,0,0,1,0,.002000000095,0,0,1];
  owner.extras.morphloomSourceSpecReference={schema:'morphloom.source-spec-reference/0.1',state:'before-edit-reference',sourceSha256:sourceFingerprint,sourceSpec:owner.extras.sourceSpec};delete owner.extras.sourceSpec;
  d.asset.extras={morphloomBakedTransform:{schema:'morphloom.baked-transform/0.1',sourceSha256:sourceFingerprint,node:'spur_gear',translationMm:[2,0,0],coordinates:'glTF right-handed Y-up world, millimeters',currentEditableIRAvailable:false,sourceSpecState:'before-edit-reference',referenceNodes:[ownerIndex]}};
  return {project,original,current:pack(d,bin)};
 }finally{built.dispose();}
}
it('regenerates a separate edited native source, preserves inputs and all other source fields',async()=>{
 try{const f=await fixture(),before=await sha256(new Uint8Array(f.current)),result=await reconstructTranslatedSource(f.original,f.current),expected=structuredClone(f.project);expected.parts[0].position=[2,0,0];expect(result.project).toEqual(expected);expect(result.receipt.currentEditableSourceAvailable).toBe(true);expect(result.receipt.inputGlbEditableIrAvailable).toBe(false);expect(await sha256(new Uint8Array(f.current))).toBe(before);}finally{vi.unstubAllGlobals();}
});
it('rejects authentic bound bytes that cannot be regenerated from the original IR',async()=>{
 try{const f=await fixture(false,true);await expect(reconstructTranslatedSource(f.original,f.current)).rejects.toThrow('original regenerated BIN differs');}finally{vi.unstubAllGlobals();}
});
it('preserves the existing locked-part edit refusal',async()=>{
 try{const f=await fixture(true);await expect(reconstructTranslatedSource(f.original,f.current)).rejects.toThrow('locked');}finally{vi.unstubAllGlobals();}
});
