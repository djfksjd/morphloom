import bpy,json,struct,hashlib
from pathlib import Path
from mathutils import Matrix,Quaternion,Vector
source=Path('/Users/danny/Documents/morphloom/outputs/source-translation-20261003/release/rotated-parent-input.glb');raw=source.read_bytes();document=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]]);nodes=document['nodes'];parents={c:i for i,n in enumerate(nodes)for c in n.get('children',[])}
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(source),import_shading='NORMALS',merge_vertices=False)
def local(n,converted):
 if 'matrix'in n:
  v=n['matrix'];m=Matrix([v[i:i+4]for i in range(0,16,4)]).transposed()
  if not converted:return m
  basis=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)));return Matrix.LocRotScale(*(basis@m@basis.inverted()).decompose())
 t,r,s=n.get('translation',[0,0,0]),n.get('rotation',[0,0,0,1]),n.get('scale',[1,1,1])
 if converted:return Matrix.LocRotScale(Vector((t[0],-t[2],t[1])),Quaternion((r[3],r[0],-r[2],r[1])),Vector((s[0],s[2],s[1])))
 return Matrix.LocRotScale(Vector(t),Quaternion((r[3],*r[:3])),Vector(s))
def world(i,converted):return world(parents[i],converted)@local(nodes[i],converted)if i in parents else local(nodes[i],converted)
i=next(i for i,n in enumerate(nodes)if n.get('name')=='ball_0000');basis=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)));before=basis@world(i,False)@basis.inverted();candidate=world(i,True);actual=bpy.context.scene.objects['ball_0000'].matrix_world.copy()
error=lambda a,b:max(abs(x-y)for ra,rb in zip(a,b)for x,y in zip(ra,rb))
report={'sourceSha256':hashlib.sha256(raw).hexdigest(),'blenderVersion':bpy.app.version_string,'oldMatrixComponentError':error(before,actual),'candidateMatrixComponentError':error(candidate,actual),'threshold':1e-7,'actual':[list(row)for row in actual],'old':[list(row)for row in before],'candidate':[list(row)for row in candidate]};Path('/Users/danny/Documents/morphloom/outputs/source-transform-correspondence-20261003/probe.json').write_text(json.dumps(report,indent=2)+'\n');assert report['oldMatrixComponentError']>1e-7;assert report['candidateMatrixComponentError']<=1e-7;print(json.dumps(report))
