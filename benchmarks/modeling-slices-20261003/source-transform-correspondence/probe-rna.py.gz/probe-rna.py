import bpy,json,struct,hashlib
from pathlib import Path
from mathutils import Matrix,Quaternion,Vector
source=Path('/Users/danny/Documents/morphloom/outputs/source-translation-20261003/release/rotated-parent-input.glb');raw=source.read_bytes();document=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]]);nodes=document['nodes'];parents={c:i for i,n in enumerate(nodes)for c in n.get('children',[])}
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(source),import_shading='NORMALS',merge_vertices=False)
def local(n,converted):
 if 'matrix'in n:
  v=n['matrix'];m=Matrix([v[i:i+4]for i in range(0,16,4)]).transposed()
  if not converted:return m
  basis=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)));return Matrix.LocRotScale(*(basis@m@basis.inverted()).decompose())
 t,r,s=n.get('translation',[0,0,0]),n.get('rotation',[0,0,0,1]),n.get('scale',[1,1,1])
 if converted:return Matrix.LocRotScale(Vector((t[0],-t[2],t[1])),Quaternion((r[3],r[0],-r[2],r[1])),Vector((s[0],s[2],s[1])))
 return Matrix.LocRotScale(Vector(t),Quaternion((r[3],*r[:3])),Vector(s))
def world(i,converted):return world(parents[i],converted)@local(nodes[i],converted)if i in parents else local(nodes[i],converted)
i=next(i for i,n in enumerate(nodes)if n.get('name')=='ball_0000');basis=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)));before=basis@world(i,False)@basis.inverted();candidate=world(i,True);actual=bpy.context.scene.objects['ball_0000'].matrix_world.copy()
error=lambda a,b:max(abs(x-y)for ra,rb in zip(a,b)for x,y in zip(ra,rb))
references={}
for idx,node in enumerate(nodes):
 ref=bpy.data.objects.new('source-reference-'+str(idx),None);bpy.context.scene.collection.objects.link(ref);references[idx]=ref
 if 'matrix'in node:
  value=local(node,True);t,r,s=value.decompose()
 else:
  a,q,b=node.get('translation',[0,0,0]),node.get('rotation',[0,0,0,1]),node.get('scale',[1,1,1]);t=Vector((a[0],-a[2],a[1]));r=Quaternion((q[3],q[0],-q[2],q[1]));s=Vector((b[0],b[2],b[1]))
 ref.location=t;ref.rotation_mode='QUATERNION';ref.rotation_quaternion=r;ref.scale=s
for idx,ref in references.items():
 if idx in parents:ref.parent=references[parents[idx]]
bpy.context.view_layer.update();reference=references[i].matrix_world.copy()
report={'sourceSha256':hashlib.sha256(raw).hexdigest(),'blenderVersion':bpy.app.version_string,'oldMatrixComponentError':error(before,actual),'candidateMatrixComponentError':error(candidate,actual),'sourceRNAReferenceError':error(reference,actual),'threshold':1e-7,'rootImportedQuaternion':list(bpy.context.scene.objects[nodes[0]['name']].rotation_quaternion),'rootRawQuaternion':nodes[0].get('rotation'),'actual':[list(row)for row in actual],'old':[list(row)for row in before],'candidate':[list(row)for row in candidate],'reference':[list(row)for row in reference]}
for ref in references.values():bpy.data.objects.remove(ref,do_unlink=True)
Path('/Users/danny/Documents/morphloom/outputs/source-transform-correspondence-20261003/probe-rna.json').write_text(json.dumps(report,indent=2)+'\n');assert report['oldMatrixComponentError']>1e-7;assert report['sourceRNAReferenceError']<=1e-7;print(json.dumps(report))
