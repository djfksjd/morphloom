"""Actual first-import corner normal samples in declared glTF Y-up world coordinates."""
import bpy,json,hashlib,sys
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:];assert len(args) in [3,4],'source.glb stable-mesh-id new-output.json [NORMALS|FLAT|SMOOTH]'
mode=args[3]if len(args)==4 else 'NORMALS';assert mode in ['NORMALS','FLAT','SMOOTH','flat-reference-custom']
source,selected,output=args[:3];file=Path(source);assert file.is_file() and file.stat().st_size<=256000000;assert not Path(output).exists()
bpy.ops.wm.read_factory_settings(use_empty=True)
if mode=='flat-reference-custom':
 sys.path.insert(0,str(Path(__file__).resolve().parent));from blender_source_normal_import import import_static_with_flat_reference
 import_static_with_flat_reference(file)
else:bpy.ops.import_scene.gltf(filepath=str(file.resolve()),import_shading=mode)
obj=bpy.context.scene.objects.get(selected);assert obj is not None and obj.type=='MESH';mesh=obj.data;assert len(mesh.loops)<=200000
matrix=obj.matrix_world;normal_matrix=matrix.to_3x3().inverted().transposed();rows=set()
for polygon in mesh.polygons:
 for i in polygon.loop_indices:
  p=matrix@mesh.vertices[mesh.loops[i].vertex_index].co;n=(normal_matrix@mesh.corner_normals[i].vector).normalized()
  rows.add(tuple(float(v)for v in [p.x,p.z,-p.y,n.x,n.z,-n.y]))
report={'schema':'morphloom.blender-import-normal-probe/0.2'if len(args)==4 else'morphloom.blender-import-normal-probe/0.1','importShading':'NORMALS'if mode=='flat-reference-custom'else mode,'importPolicy':mode,'sourceSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'blenderVersion':bpy.app.version_string,'stableMeshId':selected,'corners':len(mesh.loops),'uniqueSamples':len(rows),'hasCustomNormals':mesh.has_custom_normals,'coordinates':'glTF right-handed Y-up world; inverse Blender Z-up basis; meters','samples':[list(row)for row in sorted(rows)]};Path(output).parent.mkdir(parents=True,exist_ok=True);Path(output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='samples'}))
