"""Experimental measurement prototype: whole round-trip remains BLOCKED.

Opt-in static explicit NORMAL import; retain source normals with flat reference frames.

This does not use import_shading=FLAT (which discards NORMAL in Blender 5.2).
It checks exact vertex correspondence before setting original custom normals.
"""
import bpy,math
from pathlib import Path
from io_scene_gltf2.io.imp.gltf2_io_gltf import glTFImporter
from io_scene_gltf2.io.imp.gltf2_io_binary import BinaryData

POLICY='morphloom.blender-flat-normal-reference/0.1'
def _source_spec(source):
 path=Path(source);assert path.is_file() and 12<=path.stat().st_size<=256000000,'Source file budget'
 reader=glTFImporter(str(path.resolve()),{'import_user_extensions':[]})
 try:
  reader.read();reader.checks();data=reader.data
  assert not data.animations and not data.skins,'Static source only; animation/skin unsupported'
  assert len(data.meshes or [])<=128 and len(data.nodes or [])<=10000,'Scene budget'
  assert not any(b.uri for b in data.buffers or []) and not any(i.uri for i in data.images or []),'Embedded GLB only; URI unsupported'
  specs={};total=0
  for index,spec in enumerate(data.meshes or []):
   name=spec.name or 'Mesh_'+str(index);assert name not in specs,'Duplicate source mesh name';positions=[];normals=[];loops=[]
   for primitive in spec.primitives:
    assert primitive.mode in [None,4] and not primitive.targets,'Triangle static primitives only'
    assert 'NORMAL' in primitive.attributes and 'POSITION' in primitive.attributes,'Every primitive needs explicit POSITION/NORMAL'
    assert reader.data.accessors[primitive.attributes['POSITION']].count<=2000000 and reader.data.accessors[primitive.attributes['NORMAL']].count<=2000000,'Accessor budget'
    a=BinaryData.get_data_from_accessor(reader,primitive.attributes['POSITION']);n=BinaryData.get_data_from_accessor(reader,primitive.attributes['NORMAL']);assert len(a)==len(n),'Attribute correspondence'
    encoded=BinaryData.get_data_from_accessor(reader,primitive.indices)if primitive.indices is not None else range(len(a));indices=[int(v[0])if isinstance(v,(list,tuple))and len(v)==1 else int(v)for v in encoded];assert len(indices)%3==0 and len(indices)<=6000000 and all(0<=v<len(a)for v in indices),'Triangle index budget'
    used=sorted(set(indices));remap={v:i+len(positions)for i,v in enumerate(used)};loops.extend(remap[v]for v in indices);a=[a[i]for i in used];n=[n[i]for i in used]
    positions.extend((float(p[0]),-float(p[2]),float(p[1]))for p in a);normals.extend((float(v[0]),-float(v[2]),float(v[1]))for v in n)
   total+=len(positions);assert total<=2000000,'Vertex budget'
   assert all(all(math.isfinite(x)for x in row)for row in positions+normals)and all(sum(x*x for x in n)>0 for n in normals),'Non-finite/zero source attributes'
   specs[name]=(positions,normals,loops)
  return specs,total
 finally:
  reader.log.flush()
  for handler in [reader.log.console_handler,reader.log.error_console_handler,reader.log.popup_handler]:handler.close()

def import_static_with_flat_reference(source, adaptive=False):
 specs,total=_source_spec(source);path=Path(source)
 before=set(bpy.data.meshes);bpy.ops.import_scene.gltf(filepath=str(path.resolve()),import_shading='NORMALS',merge_vertices=False);imported=[mesh for mesh in bpy.data.meshes if mesh not in before];assert len(imported)==len(specs),'Missing/extra imported meshes'
 checked=[]
 for mesh in imported:
  assert mesh.name in specs,'Ambiguous import name';positions,normals,loops=specs[mesh.name];assert len(mesh.vertices)==len(positions),'Importer vertex reordering/merging unsupported'
  assert all(max(abs(float(c)-v)for c,v in zip(vertex.co,p))<=1e-8 for vertex,p in zip(mesh.vertices,positions)),'Importer vertex geometry/order mismatch'
  assert [loop.vertex_index for loop in mesh.loops]==loops,'Importer topology/order mismatch'
  checked.append((mesh,normals))
 # Validate the full import first; no partial normal mutation on an eligibility failure.
 reference_receipts=[]
 def error(mesh,normals):
  worst=0
  for loop in mesh.loops:
   actual=mesh.corner_normals[loop.index].vector;expected=normals[loop.vertex_index];dot=sum(float(a)*b for a,b in zip(actual,expected));length=math.sqrt(sum(float(a)*float(a)for a in actual)*sum(b*b for b in expected));worst=max(worst,math.degrees(math.acos(max(-1,min(1,dot/length)))))
  return worst
 for mesh,normals in checked:
  candidates=[{'mode':'native','maxInputNormalErrorDeg':error(mesh,normals)}]if adaptive else[]
  for mode in (['smooth','flat']if adaptive else['flat']):
   candidate=mesh.copy()
   try:
    candidate.shade_smooth()if mode=='smooth'else candidate.shade_flat();candidate.normals_split_custom_set_from_vertices(normals)
    candidates.append({'mode':mode,'maxInputNormalErrorDeg':error(candidate,normals)})
   finally:bpy.data.meshes.remove(candidate)
  chosen=min(candidates,key=lambda c:c['maxInputNormalErrorDeg'])
  if chosen['mode']!='native':
   mesh.shade_smooth()if chosen['mode']=='smooth'else mesh.shade_flat();mesh.normals_split_custom_set_from_vertices(normals)
  actual=error(mesh,normals)
  reference_receipts.append({'mesh':mesh.name,'chosen':chosen,'appliedMaxInputErrorDeg':actual,'candidates':candidates})
 return {'policy':'morphloom.blender-normal-reference/0.2'if adaptive else POLICY,'referenceReceipts':reference_receipts,'meshCount':len(checked),'vertices':total,'scope':'static explicit source normals; isolated reference candidates; no normal recalculation; no geometry/UV/PBR transform; all eligibility checks before application'}
